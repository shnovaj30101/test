
import numpy as np
import csv
from sklearn.ensemble import RandomForestClassifier

# Initialization
outputfile = 'output.csv'

# Load data
data = np.load('data/data.npy')
train_y = np.load('data/train_label.npy')

train_X = data[:len(train_y)]
test_X = data[len(train_y):]

# Setup random forest
rf = RandomForestClassifier(n_estimators=100, max_features=75, n_jobs=4)

rf.fit(train_X, train_y)

test_y = tf.predict(test_X)

# Write results to csv file
with open(outputfile, 'wb') as f:
  wt = csv.writer(f)

  wt.writerow(['id', 'label'])

  for i, lb in enumerate(test_y, 1):
    wt.writerow([i, lb])
