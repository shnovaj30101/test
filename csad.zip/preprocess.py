#
# Preprocess the training and testing data
#

from __future__ import print_function

import numpy as np
import csv
import os
import cPickle as pickle
from collections import Counter

# initialization
types = ['normal', 'dos', 'u2r', 'r2l', 'probe']
typ2num = dict([(typ, i) for i, typ in enumerate(types)])

with open('data/training_attack_types.txt', 'rb') as f:
  atk2typ = dict([line.split() for line in f.readlines()])
  atk2typ['normal'] = 'normal'

# read data from files
with open('data/train', 'rb') as f:
  train_data = [line[:-2] for line in f.readlines()]
  rd = csv.reader(train_data)

  train_data = np.array([row for row in rd])
  labels = train_data[:, -1]
  train_data = train_data[:, :-1]

with open('data/test.in', 'rb') as f:
  test_data = csv.reader(f)

  test_data = np.array([row for row in test_data])

data = np.append(train_data, test_data, axis=0)
train_len = train_data.shape[0]

del train_data
del test_data

prots = Counter(data[:, 1]).keys()
prot2num = dict([(prot, i) for i, prot in enumerate(prots)])

servs = Counter(data[:, 2]).keys()
serv2num = dict([(serv, i) for i, serv in enumerate(servs)])

flags = Counter(data[:, 3]).keys()
flag2num = dict([(flag, i) for i, flag in enumerate(flags)])

attacks = Counter(labels).keys()
atk2num = dict([(atk, i) for i, atk in enumerate(attacks)])

# transform to trainable data
all_data = data[:, 0].astype(np.float).reshape(-1, 1)

prots = np.zeros((data.shape[0], len(prot2num.keys())))
idx = [prot2num[prot] for prot in data[:, 1]]
prots[range(len(idx)), idx] = 1
all_data = np.append(all_data, prots, axis=1)
del prots

servs = np.zeros((data.shape[0], len(serv2num.keys())))
idx = [serv2num[serv] for serv in data[:, 2]]
servs[range(len(idx)), idx] = 1
all_data = np.append(all_data, servs, axis=1)
del servs

flags = np.zeros((data.shape[0], len(flag2num.keys())))
idx = [flag2num[flag] for flag in data[:, 3]]
flags[range(len(idx)), idx] = 1
all_data = np.append(all_data, flags, axis=1)
del flags

all_data = np.append(all_data, data[:, 4:].astype(np.float), axis=1)

del data

''' labels '''
labels = np.array([typ2num[atk2typ[atk]] for atk in labels])

# save the usable data
np.save('data/train_label.npy', labels)
np.save('data/data.npy', all_data)
